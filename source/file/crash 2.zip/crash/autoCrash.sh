#!/bin/bash

export DEVELOPER_DIR=/Applications/XCode.app/Contents/Developer

FileName=$1

for file in ./*.crash
do

./symbolicatecrash ${file} $FileName.app.dSYM > ${file}.log

done
